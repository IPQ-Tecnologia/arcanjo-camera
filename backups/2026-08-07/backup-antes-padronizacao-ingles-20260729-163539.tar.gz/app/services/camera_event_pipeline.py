import asyncio
import logging
from datetime import datetime, timezone

from app.adapters.cameras.factory import camera_adapter_factory
from app.core.config import settings
from app.domain.models.camera_event import BoundingBox, CameraEvent, RawCameraPackage
from app.messaging.kafka_producer import KafkaPublisher
from app.services.alarm_detection_payload import (
    arquivo_para_base64,
    montar_alarm_detection_message,
    recortar_deteccao_base64,
)
from app.services.appearance_memory import appearance_memory
from app.services.event_hub import event_hub
from app.services.person_tracker import (
    DetectionBox,
    TrackingDecision,
    person_tracker,
)
from app.services.person_movement import person_movement_memory
from app.services.scene_analyzer import analisar_pessoa
from app.services.scene_context_analyzer import analisar_contexto_cena
from app.services.scene_renderer import renderizar_cena_com_boxes

logger = logging.getLogger(__name__)


class CameraEventPipeline:
    def __init__(
        self,
        publisher: KafkaPublisher,
        topic: str,
        maxsize: int = 1000,
        worker_count: int = 4,
    ) -> None:
        self.publisher = publisher
        self.topic = topic
        self.worker_count = worker_count
        self.queue: asyncio.Queue[tuple[RawCameraPackage, bytes]] = asyncio.Queue(
            maxsize=maxsize
        )
        self._worker_tasks: list[asyncio.Task] = []
        self._exit_task: asyncio.Task | None = None
        self._iniciado = False

    @property
    def tamanho_fila(self) -> int:
        return self.queue.qsize()

    @property
    def capacidade_fila(self) -> int:
        return self.queue.maxsize

    async def start(self) -> None:
        if self._iniciado:
            return

        if settings.kafka_enabled:
            await self.publisher.start()
        else:
            logger.warning(
                "Kafka desativado: eventos serão processados, mas não publicados."
            )

        self._worker_tasks = [
            asyncio.create_task(
                self._worker(numero),
                name=f"camera-worker-{numero}",
            )
            for numero in range(1, self.worker_count + 1)
        ]
        self._exit_task = asyncio.create_task(
            self._monitorar_saidas(),
            name="person-exit-monitor",
        )
        self._iniciado = True
        logger.info("Pipeline iniciado com %s workers", self.worker_count)

    async def stop(self) -> None:
        if not self._iniciado:
            return

        try:
            await asyncio.wait_for(self.queue.join(), timeout=10)
        except TimeoutError:
            logger.warning("Encerrando com %s itens na fila", self.queue.qsize())

        tarefas: list[asyncio.Task] = [*self._worker_tasks]
        if self._exit_task is not None:
            tarefas.append(self._exit_task)

        for tarefa in tarefas:
            tarefa.cancel()

        if tarefas:
            await asyncio.gather(*tarefas, return_exceptions=True)

        if self.publisher.iniciado:
            await self.publisher.stop()

        await appearance_memory.limpar()
        await person_movement_memory.limpar()
        await person_tracker.limpar()

        self._worker_tasks.clear()
        self._exit_task = None
        self._iniciado = False
        logger.info("Pipeline encerrado")

    def adicionar(self, pacote: RawCameraPackage, body: bytes) -> None:
        self.queue.put_nowait((pacote, body))

    async def _monitorar_saidas(self) -> None:
        logger.info("Monitor automático de saídas iniciado")

        while True:
            try:
                await asyncio.sleep(1)
                saidas = await person_tracker.coletar_saidas()

                for saida in saidas:
                    aparencia_final = await appearance_memory.finalizar(
                        saida.pessoa_id
                    )
                    movimento_final = await person_movement_memory.finalizar(
                        saida.pessoa_id
                    )
                    momento_saida = (
                        datetime.now(timezone.utc)
                        .isoformat()
                        .replace("+00:00", "Z")
                    )
                    evento_painel = {
                        "evento_id": saida.evento_id,
                        "pessoa_id": saida.pessoa_id,
                        "status": "exited",
                        "quantidade_deteccoes": saida.quantidade_deteccoes,
                        "camera": saida.camera,
                        "tipo": None,
                        "datetime": momento_saida,
                        "attributes": None,
                        "imagem": None,
                        "aparencia": (
                            aparencia_final.to_dict()
                            if aparencia_final is not None
                            else None
                        ),
                        "movimento": (
                            movimento_final.to_dict()
                            if movimento_final is not None
                            else None
                        ),
                        "contexto_cena": None,
                        "imagem_cena": None,
                        "quantidade_boxes_cena": None,
                    }
                    await event_hub.publicar(evento_painel)
                    logger.info(
                        "[RASTREAMENTO] Pessoa saiu: pessoa=%s camera=%s "
                        "deteccoes=%s amostras_visuais=%s amostras_movimento=%s "
                        "tempo_observado=%ss paineis=%s",
                        saida.pessoa_id,
                        saida.camera,
                        saida.quantidade_deteccoes,
                        (
                            aparencia_final.quantidade_amostras
                            if aparencia_final is not None
                            else 0
                        ),
                        (
                            movimento_final.quantidade_amostras
                            if movimento_final is not None
                            else 0
                        ),
                        (
                            movimento_final.tempo_observado_segundos
                            if movimento_final is not None
                            else 0
                        ),
                        event_hub.total_conexoes,
                    )

            except asyncio.CancelledError:
                logger.info("Monitor automático de saídas encerrado")
                raise
            except Exception:
                logger.exception("Erro no monitor automático de saídas")

    def _selecionar_boxes_pessoas(
        self,
        evento: CameraEvent,
    ) -> list[BoundingBox]:
        """Remove caixas inválidas, duplicadas e a caixa da imagem inteira."""

        if evento.imagem is None:
            return []

        largura_imagem = evento.imagem.largura
        altura_imagem = evento.imagem.altura
        if not largura_imagem or not altura_imagem:
            return []

        area_imagem = largura_imagem * altura_imagem
        assinaturas: set[tuple[int, int, int, int]] = set()
        caixas_validas: list[BoundingBox] = []

        for caixa in evento.bounding_boxes or []:
            if caixa.largura <= 0 or caixa.altura <= 0:
                continue

            x1 = max(0, min(caixa.x, largura_imagem - 1))
            y1 = max(0, min(caixa.y, altura_imagem - 1))
            x2 = max(x1 + 1, min(caixa.x2, largura_imagem))
            y2 = max(y1 + 1, min(caixa.y2, altura_imagem))
            largura = x2 - x1
            altura = y2 - y1
            percentual = largura * altura / area_imagem * 100

            if percentual >= 60 or percentual < 0.05:
                continue

            assinatura = (x1, y1, x2, y2)
            if assinatura in assinaturas:
                continue
            assinaturas.add(assinatura)

            if (
                x1 == caixa.x
                and y1 == caixa.y
                and largura == caixa.largura
                and altura == caixa.altura
            ):
                caixa_ajustada = caixa
            else:
                caixa_ajustada = caixa.model_copy(
                    update={
                        "x": x1,
                        "y": y1,
                        "largura": largura,
                        "altura": altura,
                        "x2": x2,
                        "y2": y2,
                    }
                )

            caixas_validas.append(caixa_ajustada)

        if not caixas_validas and evento.bounding_box_escolhida is not None:
            caixas_validas.append(evento.bounding_box_escolhida)

        caixas_validas.sort(
            key=lambda caixa: (
                caixa.x + caixa.largura / 2,
                caixa.y + caixa.altura / 2,
            )
        )
        return caixas_validas

    async def _analisar_aparencia(
        self,
        evento: CameraEvent,
        bounding_box: BoundingBox,
        pessoa_id: str,
        pacote_id: str,
    ):
        try:
            if evento.imagem is None or not evento.imagem.caminho_original:
                logger.info(
                    "[%s] Imagem sem caminho original; aparência não analisada",
                    pacote_id,
                )
                return None

            analise_visual = await asyncio.to_thread(
                analisar_pessoa,
                caminho_imagem=evento.imagem.caminho_original,
                x=bounding_box.x,
                y=bounding_box.y,
                largura=bounding_box.largura,
                altura=bounding_box.altura,
            )
            aparencia_estavel = await appearance_memory.registrar(
                pessoa_id=pessoa_id,
                analise=analise_visual,
            )
            logger.info(
                "[%s] Aparência estável: pessoa=%s cor=%s posição=%s "
                "tamanho=%s área_média=%s%% amostras=%s",
                pacote_id,
                pessoa_id,
                aparencia_estavel.cor_roupa_predominante,
                aparencia_estavel.posicao_atual,
                aparencia_estavel.tamanho_predominante,
                aparencia_estavel.percentual_medio_quadro,
                aparencia_estavel.quantidade_amostras,
            )
            return aparencia_estavel
        except Exception:
            logger.exception(
                "[%s] Não foi possível analisar a aparência da pessoa=%s",
                pacote_id,
                pessoa_id,
            )
            return None

    async def _analisar_contexto_cena(
        self,
        evento: CameraEvent,
        bounding_boxes: list[BoundingBox],
        pacote_id: str,
    ):
        try:
            if evento.imagem is None:
                return None

            largura_imagem = evento.imagem.largura
            altura_imagem = evento.imagem.altura
            if not largura_imagem or not altura_imagem:
                logger.info(
                    "[%s] Contexto não analisado: dimensões ausentes",
                    pacote_id,
                )
                return None

            contexto = await asyncio.to_thread(
                analisar_contexto_cena,
                largura_imagem=largura_imagem,
                altura_imagem=altura_imagem,
                bounding_boxes=bounding_boxes,
            )
            logger.info(
                "[%s] Contexto da cena: pessoas=%s esquerda=%s centro=%s "
                "direita=%s muito_proximos=%s proximos=%s separados=%s",
                pacote_id,
                contexto.quantidade_pessoas,
                contexto.pessoas_esquerda,
                contexto.pessoas_centro,
                contexto.pessoas_direita,
                contexto.pares_muito_proximos,
                contexto.pares_proximos,
                contexto.pares_separados,
            )
            logger.info("[%s] Descrição da cena: %s", pacote_id, contexto.descricao)
            return contexto
        except Exception:
            logger.exception("[%s] Não foi possível analisar a cena", pacote_id)
            return None

    async def _renderizar_cena(
        self,
        evento: CameraEvent,
        bounding_boxes: list[BoundingBox],
        pacote_id: str,
    ):
        try:
            if evento.imagem is None or not evento.imagem.caminho_original:
                return None
            if not bounding_boxes:
                return None

            resultado = await asyncio.to_thread(
                renderizar_cena_com_boxes,
                caminho_imagem=evento.imagem.caminho_original,
                bounding_boxes=bounding_boxes,
            )
            if resultado.quantidade_boxes == 0:
                return None

            logger.info(
                "[%s] Cena renderizada: boxes=%s dimensoes=%sx%s base64=%s caracteres",
                pacote_id,
                resultado.quantidade_boxes,
                resultado.largura_imagem,
                resultado.altura_imagem,
                len(resultado.imagem_base64),
            )
            return resultado
        except Exception:
            logger.exception(
                "[%s] Não foi possível renderizar a cena com boxes",
                pacote_id,
            )
            return None

    async def _publicar_atualizacao_parcial(
        self,
        camera: str,
        decisao: TrackingDecision,
        aparencia_estavel,
        movimento,
        contexto_cena,
        cena_renderizada,
        imagem_recorte_base64: str | None,
        indice_na_cena: int,
        total_pessoas_cena: int,
        pacote_id: str,
    ) -> None:
        atualizacao_parcial = {
            "evento_id": decisao.evento_id,
            "pessoa_id": decisao.pessoa_id,
            "status": "appearance_updated",
            "quantidade_deteccoes": decisao.quantidade_deteccoes,
            "camera": camera,
            "imagem": imagem_recorte_base64,
            "aparencia": (
                aparencia_estavel.to_dict()
                if aparencia_estavel is not None
                else None
            ),
            "movimento": (
                movimento.to_dict()
                if movimento is not None
                else None
            ),
            "contexto_cena": (
                contexto_cena.to_dict() if contexto_cena is not None else None
            ),
            "imagem_cena": (
                cena_renderizada.imagem_base64
                if cena_renderizada is not None
                else None
            ),
            "quantidade_boxes_cena": (
                cena_renderizada.quantidade_boxes
                if cena_renderizada is not None
                else 0
            ),
            "indice_na_cena": indice_na_cena,
            "total_pessoas_cena": total_pessoas_cena,
        }
        await event_hub.publicar(atualizacao_parcial)
        logger.info(
            "[%s] Atualização parcial: pessoa=%s indice=%s/%s "
            "deteccoes=%s amostras=%s movimento=%s/%s velocidade=%spx_s "
            "boxes=%s paineis=%s",
            pacote_id,
            decisao.pessoa_id,
            indice_na_cena,
            total_pessoas_cena,
            decisao.quantidade_deteccoes,
            (
                aparencia_estavel.quantidade_amostras
                if aparencia_estavel is not None
                else 0
            ),
            (
                movimento.movimento_horizontal
                if movimento is not None
                else "-"
            ),
            (
                movimento.movimento_vertical
                if movimento is not None
                else "-"
            ),
            (
                movimento.velocidade_pixels_segundo
                if movimento is not None
                else 0
            ),
            (
                cena_renderizada.quantidade_boxes
                if cena_renderizada is not None
                else 0
            ),
            event_hub.total_conexoes,
        )

    async def _processar_pessoa(
        self,
        evento: CameraEvent,
        camera: str,
        bounding_box: BoundingBox,
        decisao: TrackingDecision,
        contexto_cena,
        cena_renderizada,
        indice_na_cena: int,
        total_pessoas_cena: int,
        pacote_id: str,
        imagem_background_base64: str | None,
    ) -> str | None:
        aparencia_estavel = await self._analisar_aparencia(
            evento=evento,
            bounding_box=bounding_box,
            pessoa_id=decisao.pessoa_id,
            pacote_id=pacote_id,
        )

        movimento = await person_movement_memory.registrar(
            pessoa_id=decisao.pessoa_id,
            bbox=decisao.bbox,
        )
        logger.info(
            "[%s] Movimento: pessoa=%s horizontal=%s vertical=%s "
            "tendencia=%s velocidade=%spx_s distancia_total=%spx "
            "tempo=%ss amostras=%s",
            pacote_id,
            decisao.pessoa_id,
            movimento.movimento_horizontal,
            movimento.movimento_vertical,
            movimento.tendencia_distancia,
            movimento.velocidade_pixels_segundo,
            movimento.distancia_total_pixels,
            movimento.tempo_observado_segundos,
            movimento.quantidade_amostras,
        )

        if not decisao.deve_processar:
            imagem_recorte_base64 = None

            if (
                evento.imagem is not None
                and evento.imagem.caminho_original
            ):
                try:
                    imagem_recorte_base64 = (
                        await asyncio.to_thread(
                            recortar_deteccao_base64,
                            evento.imagem.caminho_original,
                            bounding_box,
                        )
                    )
                except Exception:
                    logger.exception(
                        "[%s] Não foi possível atualizar "
                        "o recorte da pessoa=%s",
                        pacote_id,
                        decisao.pessoa_id,
                    )

            await self._publicar_atualizacao_parcial(
                camera=camera,
                decisao=decisao,
                aparencia_estavel=aparencia_estavel,
                movimento=movimento,
                contexto_cena=contexto_cena,
                cena_renderizada=cena_renderizada,
                imagem_recorte_base64=(
                    imagem_recorte_base64
                ),
                indice_na_cena=indice_na_cena,
                total_pessoas_cena=total_pessoas_cena,
                pacote_id=pacote_id,
            )
            logger.info(
                "[%s] Evento repetido suprimido: pessoa=%s indice=%s/%s amostras=%s",
                pacote_id,
                decisao.pessoa_id,
                indice_na_cena,
                total_pessoas_cena,
                (
                    aparencia_estavel.quantidade_amostras
                    if aparencia_estavel is not None
                    else 0
                ),
            )
            return imagem_background_base64

        if evento.imagem is None or not evento.imagem.caminho_original:
            logger.info("[%s] Pessoa ignorada: caminho original ausente", pacote_id)
            return imagem_background_base64

        if imagem_background_base64 is None:
            imagem_background_base64 = await asyncio.to_thread(
                arquivo_para_base64,
                evento.imagem.caminho_original,
            )

        try:
            mensagem = await asyncio.to_thread(
                montar_alarm_detection_message,
                evento,
                bounding_box=bounding_box,
                evento_id=decisao.evento_id,
                imagem_background_base64=imagem_background_base64,
            )
        except ValueError as erro:
            logger.info(
                "[%s] Pessoa ignorada: pessoa=%s erro=%s",
                pacote_id,
                decisao.pessoa_id,
                erro,
            )
            return imagem_background_base64

        evento_painel = {
            "evento_id": decisao.evento_id,
            "pessoa_id": decisao.pessoa_id,
            "status": decisao.status,
            "quantidade_deteccoes": decisao.quantidade_deteccoes,
            "camera": mensagem.device.name,
            "tipo": mensagem.event.type,
            "datetime": mensagem.event.datetime,
            "attributes": (
                mensagem.event.attributes.model_dump(
                    mode="json"
                )
                if mensagem.event.attributes is not None
                else None
            ),
            "imagem": mensagem.event.images.detection,
            "aparencia": (
                aparencia_estavel.to_dict()
                if aparencia_estavel is not None
                else None
            ),
            "movimento": movimento.to_dict(),
            "contexto_cena": (
                contexto_cena.to_dict() if contexto_cena is not None else None
            ),
            "imagem_cena": (
                cena_renderizada.imagem_base64
                if cena_renderizada is not None
                else None
            ),
            "quantidade_boxes_cena": (
                cena_renderizada.quantidade_boxes
                if cena_renderizada is not None
                else 0
            ),
            "indice_na_cena": indice_na_cena,
            "total_pessoas_cena": total_pessoas_cena,
        }
        await event_hub.publicar(evento_painel)
        logger.info(
            "[%s] Pessoa enviada ao painel: pessoa=%s status=%s indice=%s/%s paineis=%s",
            pacote_id,
            decisao.pessoa_id,
            decisao.status,
            indice_na_cena,
            total_pessoas_cena,
            event_hub.total_conexoes,
        )

        if not settings.kafka_enabled:
            logger.info(
                "[%s] Payload pronto; Kafka desativado: pessoa=%s",
                pacote_id,
                decisao.pessoa_id,
            )
            return imagem_background_base64

        resultado = await self.publisher.publicar(
            topico=self.topic,
            evento_id=decisao.evento_id,
            dados=mensagem.model_dump(mode="json"),
        )
        logger.info(
            "[%s] Pessoa publicada em %s p=%s offset=%s pessoa=%s indice=%s/%s",
            pacote_id,
            resultado["topico"],
            resultado["particao"],
            resultado["offset"],
            decisao.pessoa_id,
            indice_na_cena,
            total_pessoas_cena,
        )
        return imagem_background_base64

    async def _worker(self, numero: int) -> None:
        logger.info("Worker %s iniciado", numero)

        while True:
            pacote, body = await self.queue.get()

            try:
                adapter = camera_adapter_factory.encontrar_adapter(
                    content_type=pacote.content_type,
                    body=body,
                )
                logger.info(
                    "[%s] Worker %s usando %s",
                    pacote.evento_id,
                    numero,
                    adapter.__class__.__name__,
                )

                evento = await asyncio.to_thread(adapter.normalizar, pacote, body)

                logger.info(
                    "[%s] OBJETO NORMALIZADO (%s):\n%s",
                    pacote.evento_id,
                    evento.fabricante,
                    evento.model_dump_json(indent=2),
                )

                if evento.imagem is None:
                    logger.info(
                        "[%s] Evento ignorado: não possui imagem",
                        pacote.evento_id,
                    )
                    continue

                bounding_boxes = self._selecionar_boxes_pessoas(evento)
                if not bounding_boxes:
                    logger.info(
                        "[%s] Evento ignorado: não possui boxes válidas de pessoas",
                        pacote.evento_id,
                    )
                    continue

                camera = (
                    evento.nome_camera
                    or evento.camera_id
                    or evento.ip_camera
                    or "Camera desconhecida"
                )
                caixas_rastreamento = [
                    DetectionBox(
                        x=caixa.x,
                        y=caixa.y,
                        largura=caixa.largura,
                        altura=caixa.altura,
                    )
                    for caixa in bounding_boxes
                ]
                decisoes = await person_tracker.registrar_lote(
                    camera=camera,
                    evento_id=evento.evento_id,
                    bboxes=caixas_rastreamento,
                )

                if len(decisoes) != len(bounding_boxes):
                    raise RuntimeError(
                        "Quantidade de decisões diferente da quantidade de boxes"
                    )

                total_pessoas = len(bounding_boxes)
                logger.info(
                    "[%s] Rastreamento em lote: pessoas=%s ids=%s",
                    pacote.evento_id,
                    total_pessoas,
                    [
                        (decisao.pessoa_id, decisao.status)
                        for decisao in decisoes
                    ],
                )

                contexto_cena = await self._analisar_contexto_cena(
                    evento=evento,
                    bounding_boxes=bounding_boxes,
                    pacote_id=pacote.evento_id,
                )
                cena_renderizada = await self._renderizar_cena(
                    evento=evento,
                    bounding_boxes=bounding_boxes,
                    pacote_id=pacote.evento_id,
                )

                imagem_background_base64: str | None = None
                for indice, (bounding_box, decisao) in enumerate(
                    zip(bounding_boxes, decisoes, strict=True),
                    start=1,
                ):
                    imagem_background_base64 = await self._processar_pessoa(
                        evento=evento,
                        camera=camera,
                        bounding_box=bounding_box,
                        decisao=decisao,
                        contexto_cena=contexto_cena,
                        cena_renderizada=cena_renderizada,
                        indice_na_cena=indice,
                        total_pessoas_cena=total_pessoas,
                        pacote_id=pacote.evento_id,
                        imagem_background_base64=imagem_background_base64,
                    )

            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("[%s] Erro no processamento", pacote.evento_id)
            finally:
                self.queue.task_done()
