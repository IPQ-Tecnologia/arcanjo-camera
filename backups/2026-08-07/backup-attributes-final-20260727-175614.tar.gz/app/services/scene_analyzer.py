from __future__ import annotations

import colorsys
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import median
from typing import Literal

from PIL import Image, ImageFilter


PosicaoHorizontal = Literal[
    "esquerda",
    "centro",
    "direita",
]

TamanhoNoQuadro = Literal[
    "pequeno",
    "medio",
    "grande",
]


@dataclass(frozen=True)
class PersonVisualAnalysis:
    cor_roupa_aproximada: str

    rgb_representativo: tuple[
        int,
        int,
        int,
    ]

    posicao_horizontal: PosicaoHorizontal
    tamanho_no_quadro: TamanhoNoQuadro
    percentual_quadro: float
    descricao: str

    def to_dict(self) -> dict:
        dados = asdict(self)

        dados["rgb_representativo"] = list(
            self.rgb_representativo
        )

        return dados


def analisar_pessoa(
    caminho_imagem: str | Path,
    x: int,
    y: int,
    largura: int,
    altura: int,
) -> PersonVisualAnalysis:
    caminho = Path(caminho_imagem)

    if not caminho.is_file():
        raise FileNotFoundError(
            f"Imagem não encontrada: {caminho}"
        )

    if largura <= 0 or altura <= 0:
        raise ValueError(
            "A bounding box deve possuir largura "
            "e altura positivas"
        )

    with Image.open(caminho) as imagem_aberta:
        imagem = imagem_aberta.convert("RGB")

        largura_imagem, altura_imagem = (
            imagem.size
        )

        x1 = max(
            0,
            min(
                int(x),
                largura_imagem - 1,
            ),
        )

        y1 = max(
            0,
            min(
                int(y),
                altura_imagem - 1,
            ),
        )

        x2 = max(
            x1 + 1,
            min(
                int(x + largura),
                largura_imagem,
            ),
        )

        y2 = max(
            y1 + 1,
            min(
                int(y + altura),
                altura_imagem,
            ),
        )

        largura_pessoa = x2 - x1
        altura_pessoa = y2 - y1

        regiao_roupa = _recortar_regiao_roupa(
            imagem=imagem,
            x1=x1,
            y1=y1,
            largura=largura_pessoa,
            altura=altura_pessoa,
        )

        rgb = _obter_cor_representativa(
            regiao_roupa
        )

        cor = classificar_cor_rgb(
            rgb
        )

        posicao = _classificar_posicao(
            centro_x=(
                x1 + largura_pessoa / 2
            ),
            largura_imagem=largura_imagem,
        )

        percentual_quadro = round(
            (
                largura_pessoa
                * altura_pessoa
            )
            / (
                largura_imagem
                * altura_imagem
            )
            * 100,
            2,
        )

        tamanho = _classificar_tamanho(
            percentual_quadro
        )

        descricao = _montar_descricao(
            cor=cor,
            posicao=posicao,
            tamanho=tamanho,
        )

        return PersonVisualAnalysis(
            cor_roupa_aproximada=cor,
            rgb_representativo=rgb,
            posicao_horizontal=posicao,
            tamanho_no_quadro=tamanho,
            percentual_quadro=percentual_quadro,
            descricao=descricao,
        )


def _recortar_regiao_roupa(
    imagem: Image.Image,
    x1: int,
    y1: int,
    largura: int,
    altura: int,
) -> Image.Image:
    """
    Recorta a região central do tronco.

    A área é mais estreita que a bounding box para
    reduzir fundo, braços, rosto, mãos e calça.
    """

    roupa_x1 = int(
        x1 + largura * 0.27
    )

    roupa_x2 = int(
        x1 + largura * 0.73
    )

    roupa_y1 = int(
        y1 + altura * 0.25
    )

    roupa_y2 = int(
        y1 + altura * 0.58
    )

    roupa_x2 = max(
        roupa_x1 + 1,
        roupa_x2,
    )

    roupa_y2 = max(
        roupa_y1 + 1,
        roupa_y2,
    )

    return imagem.crop(
        (
            roupa_x1,
            roupa_y1,
            roupa_x2,
            roupa_y2,
        )
    )


def _obter_cor_representativa(
    regiao: Image.Image,
) -> tuple[int, int, int]:
    """
    Calcula uma cor robusta da roupa.

    O método anterior descartava apenas os pixels
    claros, deixando o resultado artificialmente
    escuro. Agora são removidas pequenas parcelas
    das sombras mais escuras e dos reflexos mais
    claros antes de calcular a mediana RGB.
    """

    regiao_reduzida = regiao.resize(
        (64, 64),
        Image.Resampling.LANCZOS,
    )

    regiao_suavizada = (
        regiao_reduzida.filter(
            ImageFilter.MedianFilter(
                size=3
            )
        )
    )

    pixels = list(
        regiao_suavizada.getdata()
    )

    if not pixels:
        return (0, 0, 0)

    pixels_ordenados = sorted(
        pixels,
        key=_calcular_luminancia,
    )

    quantidade = len(
        pixels_ordenados
    )

    corte = int(
        quantidade * 0.08
    )

    if (
        corte > 0
        and quantidade - corte > corte
    ):
        candidatos = pixels_ordenados[
            corte:quantidade - corte
        ]
    else:
        candidatos = pixels_ordenados

    quantidade_minima = max(
        100,
        quantidade // 3,
    )

    if (
        len(candidatos)
        < quantidade_minima
    ):
        candidatos = pixels

    vermelho = int(
        round(
            median(
                pixel[0]
                for pixel in candidatos
            )
        )
    )

    verde = int(
        round(
            median(
                pixel[1]
                for pixel in candidatos
            )
        )
    )

    azul = int(
        round(
            median(
                pixel[2]
                for pixel in candidatos
            )
        )
    )

    return (
        vermelho,
        verde,
        azul,
    )


def _calcular_luminancia(
    rgb: tuple[int, int, int],
) -> float:
    vermelho, verde, azul = rgb

    return (
        vermelho * 0.2126
        + verde * 0.7152
        + azul * 0.0722
    )


def classificar_cor_rgb(
    rgb: tuple[int, int, int],
) -> str:
    """
    Classifica uma cor RGB usando HSV, luminância
    e diferença entre os canais.

    A regra evita chamar qualquer cor escura de
    preta. Tons escuros com saturação perceptível
    são classificados como azul-escura,
    verde-escura, vermelha-escura ou roxa-escura.
    """

    vermelho, verde, azul = (
        max(0, min(255, int(canal)))
        for canal in rgb
    )

    r = vermelho / 255
    g = verde / 255
    b = azul / 255

    matiz, saturacao, brilho = (
        colorsys.rgb_to_hsv(
            r,
            g,
            b,
        )
    )

    matiz_graus = (
        matiz * 360
    )

    luminancia = _calcular_luminancia(
        (
            vermelho,
            verde,
            azul,
        )
    )

    maior_canal = max(
        vermelho,
        verde,
        azul,
    )

    menor_canal = min(
        vermelho,
        verde,
        azul,
    )

    diferenca_canais = (
        maior_canal
        - menor_canal
    )

    # Preto verdadeiro ou preto iluminado:
    # luminosidade muito baixa e canais próximos.
    if (
        brilho <= 0.14
        or (
            brilho <= 0.28
            and diferenca_canais <= 25
        )
        or (
            luminancia <= 58
            and saturacao <= 0.32
        )
    ):
        return "preta"

    # Branco e tons neutros.
    if (
        luminancia >= 218
        and saturacao <= 0.18
    ):
        return "branca"

    if saturacao <= 0.16:
        if luminancia < 135:
            return "cinza-escura"

        return "cinza"

    # Marrom e bege ficam na faixa de laranja,
    # mas são separados pelo brilho.
    if (
        15 <= matiz_graus < 48
        and saturacao >= 0.22
    ):
        if brilho <= 0.62:
            return "marrom"

        if (
            saturacao <= 0.48
            and brilho >= 0.66
        ):
            return "bege"

        return "laranja"

    cor_base = _classificar_por_matiz(
        matiz_graus
    )

    # Preserva a cor de roupas escuras saturadas.
    if brilho <= 0.42:
        cores_escuras = {
            "vermelha": "vermelha-escura",
            "verde": "verde-escura",
            "azul": "azul-escura",
            "roxa": "roxa-escura",
        }

        return cores_escuras.get(
            cor_base,
            cor_base,
        )

    return cor_base


def _classificar_por_matiz(
    matiz_graus: float,
) -> str:
    if (
        matiz_graus < 15
        or matiz_graus >= 345
    ):
        return "vermelha"

    if matiz_graus < 48:
        return "laranja"

    if matiz_graus < 72:
        return "amarela"

    if matiz_graus < 170:
        return "verde"

    if matiz_graus < 200:
        return "azul"

    if matiz_graus < 260:
        return "azul"

    if matiz_graus < 315:
        return "roxa"

    return "rosa"


def _classificar_cor(
    rgb: tuple[int, int, int],
) -> str:
    """
    Mantém compatibilidade com testes ou imports
    antigos que utilizavam a função privada.
    """

    return classificar_cor_rgb(
        rgb
    )


def _classificar_posicao(
    centro_x: float,
    largura_imagem: int,
) -> PosicaoHorizontal:
    proporcao = (
        centro_x
        / largura_imagem
    )

    if proporcao < 0.34:
        return "esquerda"

    if proporcao < 0.67:
        return "centro"

    return "direita"


def _classificar_tamanho(
    percentual_quadro: float,
) -> TamanhoNoQuadro:
    if percentual_quadro < 3:
        return "pequeno"

    if percentual_quadro < 12:
        return "medio"

    return "grande"


def _montar_descricao(
    cor: str,
    posicao: PosicaoHorizontal,
    tamanho: TamanhoNoQuadro,
) -> str:
    descricoes_posicao = {
        "esquerda": "à esquerda",
        "centro": "no centro",
        "direita": "à direita",
    }

    descricoes_tamanho = {
        "pequeno": (
            "ocupando uma pequena parte "
            "do enquadramento"
        ),
        "medio": (
            "ocupando uma parte intermediária "
            "do enquadramento"
        ),
        "grande": (
            "ocupando uma grande parte "
            "do enquadramento"
        ),
    }

    return (
        "Pessoa com roupa predominantemente "
        f"{cor}, localizada "
        f"{descricoes_posicao[posicao]} da cena, "
        f"{descricoes_tamanho[tamanho]}."
    )
