from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    origem: str | None = None

    x: int
    y: int

    largura: int
    altura: int

    x2: int
    y2: int

    proporcao_imagem: float | None = None


class ImageData(BaseModel):
    largura: int | None = None
    altura: int | None = None

    formato: str | None = None

    caminho_original: str | None = None
    caminho_marcada: str | None = None


class CameraEvent(BaseModel):
    schema_version: str = "1.0"

    evento_id: str

    fabricante: str
    modelo_camera: str | None = None

    camera_id: str | None = None
    nome_camera: str | None = None
    ip_camera: str | None = None

    tipo_evento: str
    estado: str | None = None
    data_hora: datetime

    alvo_detectado: str | None = None

    bounding_boxes: list[BoundingBox] = Field(
        default_factory=list
    )

    bounding_box_escolhida: BoundingBox | None = None

    imagem: ImageData | None = None

    dados_extras: dict[str, Any] = Field(
        default_factory=dict
    )


class RawCameraPackage(BaseModel):
    evento_id: str
    recebido_em: datetime

    content_type: str
    ip_camera: str | None = None

    caminho_pacote: str