from pydantic import BaseModel


class AlarmDevice(BaseModel):
    name: str


class AlarmImages(BaseModel):
    background: str
    detection: str


class AlarmEventData(BaseModel):
    id: str
    type: str
    timestamp: int
    datetime: str
    images: AlarmImages


class AlarmDetectionMessage(BaseModel):
    device: AlarmDevice
    event: AlarmEventData